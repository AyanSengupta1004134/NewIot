package com.mouser.iotshow;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.independentsoft.share.User;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Objects;

public class UserCheck extends AppCompatActivity {

    EditText email,phn;
    String mail,phone;
    Button check;
    String name,cname,designation,emailjson,phonejson;

    ArrayList<String> phonearr = new ArrayList<String>();
    ArrayList<String> emailarr = new ArrayList<String>();

//    String phonearr[]= new String[100];
//    String emailarr[] = new String[100];
    int i = 0,match = 0;
    public  static  int user = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_check);

        email = (EditText) findViewById(R.id.email);
        phn = (EditText) findViewById(R.id.phn);



        //Toast.makeText(UserCheck.this,"Phone value"+phone,Toast.LENGTH_SHORT).show();


        StringBuffer sb = new StringBuffer();
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(getAssets().open(
                    "Contact.json")));
            String temp;
            while ((temp = br.readLine()) != null)
                sb.append(temp);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                br.close(); // stop reading
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        String myjsonstring = sb.toString();


        try {

            JSONObject jsonObjMain = new JSONObject(myjsonstring);


            JSONArray jsonArray = jsonObjMain.getJSONArray("Contacts");


            for (int i = 0; i<jsonArray.length(); i++) {


                JSONObject jsonObj = jsonArray.getJSONObject(i);


                name = jsonObj.getString("Name");
                cname = jsonObj.getString("CName");
                designation = jsonObj.getString("Designation");
                emailjson = jsonObj.getString("Email");
                phonejson = jsonObj.getString("Phone");

                phonearr.add(phonejson);
                emailarr.add(emailjson);


            }

        } catch (JSONException e) {

            e.printStackTrace();
        }



        check = (Button) findViewById(R.id.check);
        check.getBackground().setAlpha(30);



        check.setOnClickListener(new View.OnClickListener() {
            @Override
               public void onClick(View v) {


                {
                    mail = email.getText().toString();
                    phone = phn.getText().toString();
                    if(phonearr.contains(phone))
                    {
                        //Toast.makeText(UserCheck.this,"Found ",Toast.LENGTH_SHORT).show();
                        match = 1;
                        user = 1;
                        if(MainActivity.c == 0)
                        {
                            Intent intent = new Intent(UserCheck.this, UserInfo.class);
                            intent.putExtra("phone",phone);
                            startActivity(intent);

                        }
                        else if(MainActivity.c == 1){
                            Intent intent = new Intent(UserCheck.this, Feedback.class);
                            intent.putExtra("phone",phone);
                            startActivity(intent);
                        }

                    }

                    else  if(emailarr.contains(mail))
                    {
                        match = 1;
                        user = 2;
                        if(MainActivity.c == 0)
                        {
                            Intent intent = new Intent(UserCheck.this, UserInfo.class);
                            intent.putExtra("email",mail);
                            startActivity(intent);

                        }
                        else if(MainActivity.c == 1){
                            Intent intent = new Intent(UserCheck.this, Feedback.class);
                            intent.putExtra("email",mail);
                            startActivity(intent);
                        }
                    }
                    else{

                        Toast.makeText(UserCheck.this,R.string.toast, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(UserCheck.this, Registration.class);
                        startActivity(intent);

                    }

                    overridePendingTransition(R.anim.translate, R.anim.translate);
                }
           }
        });


    }


    @Override
    public void onBackPressed() {
        // finish() is called in super: we only override this method to be able to override the transition
        super.onBackPressed();
        UserCheck.this.finish();
        Intent intent = new Intent(UserCheck.this,MainActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_and_changebounds, R.anim.slide_and_changebounds_sequential);
    }
}


